# encoding=utf8
import os

from sklearn.metrics import precision_score, recall_score, f1_score

class EvaluateTool(object):

    @staticmethod
    def evaluate(pred, dataset, args):
        pred_sdi = [pred_i[0] for pred_i in pred]
        pred_mdi = [pred_i[1] for pred_i in pred]
        pred_edi = [pred_i[2] for pred_i in pred]

        gold_sdi = [gold_i['consistency'][0] for gold_i in dataset]
        gold_mdi = [gold_i['consistency'][1] for gold_i in dataset]
        gold_edi = [gold_i['consistency'][2] for gold_i in dataset]
        summary = {}

        if not os.path.exists(args.dir.output):
            os.makedirs(args.dir.output)
        summary["precision_sdi"], summary["precision_mdi"], summary["precision_edi"] = precision_score(y_pred=pred_sdi, y_true=gold_sdi), precision_score(y_pred=pred_mdi, y_true=gold_mdi), precision_score(y_pred=pred_edi, y_true=gold_edi)
        summary["recall_sdi"], summary["recall_mdi"], summary["recall_edi"] = recall_score(y_pred=pred_sdi,y_true=gold_sdi), recall_score(y_pred=pred_mdi, y_true=gold_mdi), recall_score(y_pred=pred_edi, y_true=gold_edi)
        summary["f1_sdi"], summary["f1_mdi"], summary["f1_edi"] = f1_score(y_pred=pred_sdi, y_true=gold_sdi), f1_score(y_pred=pred_mdi, y_true=gold_mdi), f1_score(y_pred=pred_edi, y_true=gold_edi)
        summary["overall_acc"] = sum([1 for pred_i, gold_i in zip(pred, dataset) if pred_i == gold_i['consistency']]) / len(dataset)

        return summary
