# encoding=utf8
import json
import os

import numpy as np
from sklearn.metrics import precision_score, recall_score, f1_score


class DatasetTool(object):
    @staticmethod
    def load_data(data_path):
        """
        Load the data from data path.
        :param data_path: the json file path
        :return: infos and consistency_tuples
        each <info> is the constructed format of dialogue.
        each <consistency_tuple> is a tuple of (qi,hi,kbi)
        """
        with open(data_path) as f:
            raw_data = json.load(f)
        data = []
        for dialogue_components_item in raw_data:
            constructed_info, consistency = DatasetTool.get_info(dialogue_components_item)
            data_item = dict()
            data_item["constructed_info"] = constructed_info
            data_item["consistency"] = consistency
            data.append(data_item)
        return data

    @staticmethod
    def get_info(dialogue_components_item):
        """
        Transfer a dialogue item from the data
        :param dialogue_components_item: a dialogue(id, dialogue, kb, (qi,hi,kbi)) from data file (json item)
        :param domain: the domain of the data file
        :return: constructed_info: the constructed info which concat the info and format as
        the PhD. Qin mentioned.
                consistency: (qi,hi,kbi)
        """
        dialogue = dialogue_components_item["log"]
        history_sentences = ''
        for turns in dialogue:
            if turns["id"]=="Patients":
                history_sentences += "[Patient] "+turns["Sentence"]
            else:
                history_sentences += "[Doctor] " + turns["Sentence"]

        if 'kb' in dialogue_components_item.keys():
            kbss=''
            # print("kb",dialogue_components_item['kb'])
            for kbs in dialogue_components_item['kb']:
                for k,v in kbs.items():
                    kbss = kbss+"疾病："+k+"； 症状："+' '.join(v['symptom'])+"； 药物："+' '.join(v['medicine'])+"； 所需检查："+' '.join(v['examination'])+'，'
            history_sentences = '[SKB]'+kbss+'[EKB]'


        consistency = [float(x) for x in
                       [dialogue_components_item["sdi"], dialogue_components_item["mdi"],
                        dialogue_components_item["edi"]]]

        # constructed_info = DatasetTool.construct_info(kb_expanded, history_sentences)

        return history_sentences, consistency

    @staticmethod
    def expand_kb(knowledge_base, domain):
        """
        Expand the kb into (subject, relation, object) representation.
        :param knowledge_base: kb a list of dict.
        :param domain: the domain of the data
        :return: a list of list each item is a (subject, relation, object) representation.
        """
        expanded = []
        if domain == "navigate":
            for kb_row in knowledge_base:
                kb_row_list = []
                entity = kb_row['poi']
                for attribute_key in kb_row.keys():
                    kb_row_list.append((entity, attribute_key, kb_row[attribute_key]))
                expanded.append(kb_row_list)
        elif domain == "calendar":
            if knowledge_base == None:
                return []
            for kb_row in knowledge_base:
                kb_row_list = []
                entity = kb_row['event']
                for attribute_key in kb_row.keys():
                    if kb_row[attribute_key] == "-":
                        continue
                    kb_row_list.append((entity, attribute_key, kb_row[attribute_key]))
                expanded.append(kb_row_list)
        elif domain == "weather":
            for kb_row in knowledge_base:
                kb_row_list = []
                entity = kb_row['location']
                for attribute_key in kb_row.keys():
                    kb_row_list.append((entity, attribute_key, kb_row[attribute_key]))
                expanded.append(kb_row_list)
        else:
            print("Dataset is out of range(navigate, weather, calendar). Please recheck the path you have set.")
            assert False
        return expanded

    @staticmethod
    def construct_info(kb_expanded, history_sentences):
        """
        Concatenate the kb_expanded and history_sentences
        :param kb_expanded: the (subject, relation, object) representation expanded kb.
        :param history_sentences: history sentences.
        :return: the concatenated string.
        """
        construct_info = ''
        construct_info += ' [SOK] '
        for row in kb_expanded:
            construct_info += ' '.join([triple[1] + " " + triple[2] for triple in row])
            construct_info += ' ; '
        construct_info += ' [EOK] '

        for i, sentence in enumerate(history_sentences):
            if i % 2 == 0:
                construct_info += " [USR] " + sentence
            else:
                construct_info += " [SYS] " + sentence
        return construct_info

    @staticmethod
    def load_entity(args):
        entities = []
        for entity_path in args.dataset.entity.split(' '):
            with open(os.path.join(args.dir.dataset, entity_path)) as f:
                global_entity = json.load(f)
            entities.extend(DatasetTool.generate_entities(global_entity))
        return entities

    @staticmethod
    def generate_entities(global_entity):
        words = []
        for key in global_entity.keys():
            words.extend([str(x).lower().replace(" ", "_") for x in global_entity[key]])
            if '_' in key:
                words.append(key)
        return sorted(list(set(words)))

    @staticmethod
    def get(args, shuffle=True):
        """
        Get the train, dev, test data in a inner format of infos, last_responses, consistencys.
        ** infos means kb+history
        :param args:
        :return: train, dev, test data
        """
        # print('args.dataset.train',args.dataset.train)
        # exit()
        # train_paths = [os.path.join(args.dir.dataset, train_path) for train_path in args.dataset.train.split(' ')]
        # dev_paths = [os.path.join(args.dir.dataset, dev_path) for dev_path in args.dataset.dev.split(' ')]
        # test_paths = [os.path.join(args.dir.dataset, test_path) for test_path in args.dataset.test.split(' ')]
        train, dev, test = [], [], []
        train.extend(DatasetTool.load_data(os.path.join(args.dir.dataset, args.dataset.train)))
        dev.extend(DatasetTool.load_data(os.path.join(args.dir.dataset, args.dataset.dev)))
        test.extend(DatasetTool.load_data(os.path.join(args.dir.dataset, args.dataset.test)))
        if shuffle:
            np.random.shuffle(train)
            np.random.shuffle(dev)
        # entities = DatasetTool.load_entity(args)
        return train, dev, test

    @staticmethod
    def evaluate(pred, dataset, args):
        pred_sdi = [pred_i[0] for pred_i in pred]
        pred_mdi = [pred_i[1] for pred_i in pred]
        pred_edi = [pred_i[2] for pred_i in pred]

        gold_sdi = [gold_i['consistency'][0] for gold_i in dataset]
        gold_mdi = [gold_i['consistency'][1] for gold_i in dataset]
        gold_edi = [gold_i['consistency'][2] for gold_i in dataset]
        summary = {}

        if not os.path.exists(args.dir.output):
            os.makedirs(args.dir.output)
        summary["precision_sdi"], summary["precision_mdi"], summary["precision_edi"] = precision_score(y_pred=pred_sdi,
                                                                                                     y_true=gold_sdi), precision_score(
            y_pred=pred_mdi, y_true=gold_mdi), precision_score(y_pred=pred_edi, y_true=gold_edi)
        summary["recall_sdi"], summary["recall_mdi"], summary["recall_edi"] = recall_score(y_pred=pred_sdi,
                                                                                         y_true=gold_sdi), recall_score(
            y_pred=pred_mdi, y_true=gold_mdi), recall_score(y_pred=pred_edi, y_true=gold_edi)
        summary["f1_sdi"], summary["f1_mdi"], summary["f1_edi"] = f1_score(y_pred=pred_sdi, y_true=gold_sdi), f1_score(
            y_pred=pred_mdi, y_true=gold_mdi), f1_score(y_pred=pred_edi, y_true=gold_edi)
        summary["overall_acc"] = sum(
            [1 for pred_i, gold_i in zip(pred, dataset) if pred_i == gold_i['consistency']]) / len(dataset)

        return summary

    @staticmethod
    def record(pred, dataset, set_name, args):
        pass
